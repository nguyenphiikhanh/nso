using System;
using System.Collections.Generic;
using UnityEngine;

namespace NSO.Client
{
    /// <summary>
    /// Script phát Animation chuẩn NSO xuất từ Game Asset Studio cho Unity C#
    /// </summary>
    [RequireComponent(typeof(SpriteRenderer))]
    public class NsoAnimationPlayer : MonoBehaviour
    {
        [System.Serializable]
        public class SpriteSlice
        {
            public int id;
            public int x;
            public int y;
            public int w;
            public int h;
        }

        [System.Serializable]
        public class FramePart
        {
            public int id;
            public int dx;
            public int dy;
            public int flip;
            public int onTop;
        }

        [System.Serializable]
        public class Frame
        {
            public List<FramePart> parts = new List<FramePart>();
        }

        [System.Serializable]
        public class AnimationClipData
        {
            public string name;
            public float fps = 10f;
            public int[] sequence;
        }

        [System.Serializable]
        public class AnimationPackage
        {
            public string entityName;
            public List<SpriteSlice> sprites = new List<SpriteSlice>();
            public List<Frame> frames = new List<Frame>();
            public List<AnimationClipData> clips = new List<AnimationClipData>();
        }

        [Header("Animation Data")]
        public TextAsset animationJson;
        public Texture2D spriteTexture;

        [Header("Playback")]
        public string activeClip = "idle";
        public bool isPlaying = true;
        public float playbackSpeed = 1.0f;

        private SpriteRenderer sr;
        private AnimationPackage data;
        private int currentSequenceStep = 0;
        private float frameTimer = 0f;
        private Dictionary<int, Sprite> cachedSprites = new Dictionary<int, Sprite>();

        void Awake()
        {
            sr = GetComponent<SpriteRenderer>();
            if (animationJson != null)
            {
                LoadData(animationJson.text);
            }
        }

        public void LoadData(string json)
        {
            data = JsonUtility.FromJson<AnimationPackage>(json);
            BuildSpriteCache();
        }

        void BuildSpriteCache()
        {
            if (spriteTexture == null || data == null) return;
            cachedSprites.Clear();

            int texH = spriteTexture.height;
            foreach (var s in data.sprites)
            {
                // Unity Texture coordinate (0,0 tại góc dưới bên trái)
                Rect r = new Rect(s.x, texH - s.y - s.h, s.w, s.h);
                Sprite sp = Sprite.Create(spriteTexture, r, new Vector2(0.5f, 0.5f), 100f);
                cachedSprites[s.id] = sp;
            }
        }

        void Update()
        {
            if (!isPlaying || data == null || data.clips.Count == 0) return;

            AnimationClipData clip = data.clips.Find(c => c.name.Equals(activeClip, StringComparison.OrdinalIgnoreCase));
            if (clip == null || clip.sequence == null || clip.sequence.Length == 0) return;

            frameTimer += Time.deltaTime * playbackSpeed;
            float interval = 1f / Mathf.Max(1f, clip.fps);

            if (frameTimer >= interval)
            {
                frameTimer -= interval;
                currentSequenceStep = (currentSequenceStep + 1) % clip.sequence.Length;
                RenderFrame(clip.sequence[currentSequenceStep]);
            }
        }

        void RenderFrame(int frameIndex)
        {
            if (data == null || frameIndex < 0 || frameIndex >= data.frames.Count) return;
            Frame f = data.frames[frameIndex];
            if (f.parts.Count > 0)
            {
                // Render part chính đầu tiên
                int spriteId = f.parts[0].id;
                if (cachedSprites.TryGetValue(spriteId, out Sprite sp))
                {
                    sr.sprite = sp;
                    sr.flipX = f.parts[0].flip == 1;
                }
            }
        }
    }
}
