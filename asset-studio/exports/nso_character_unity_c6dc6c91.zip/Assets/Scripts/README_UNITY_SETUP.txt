=== HƯỚNG DẪN IMPORT VÀO UNITY C# ===
Gói xuất từ Game Asset Studio cho Nhân Vật (Option D - Hybrid)

1. CẤU TRÚC THƯ MỤC:
   Assets/Resources/Data/NsoExport/
     ├── character_actions.json   -> Timeline hành động (Idle, Walk, Attack, Jump) kèm lungeX, jumpY, rot vũ khí
     └── character_parts.json     -> Thông số từng Part và tọa độ (dx, dy) của từng Frame
   Assets/Resources/Sprites/Small/
     └── *.png                    -> Toàn bộ sprite PNG của các Part đang trang bị (35 ảnh)

2. TẠO GAMEOBJECT NHÂN VẬT TRONG UNITY:
   Tạo 1 GameObject "NsoCharacter" với các SpriteRenderer con theo thứ tự Sorting Order:
     - Leg (Chân)       : Order in Layer = 10
     - Body (Thân)      : Order in Layer = 11
     - Head (Đầu)       : Order in Layer = 12
     - Weapon (Vũ khí)  : Order in Layer = 13 (hoặc 9 nếu nằm sau thân)

3. LƯU Ý CHO UNITY C#:
   - Texture Type của ảnh PNG: Chọn "Sprite (2D and UI)".
   - Sprite Mode: "Single", Filter Mode: "Point (no filter)" để giữ nguyên pixel art NSO.
   - Khi chạy Action Attack hoặc Jump: đọc giá trị "lungeX" và "jumpY" trong character_actions.json
     để tịnh tiến vị trí root GameObject hoặc Weapon transform.
